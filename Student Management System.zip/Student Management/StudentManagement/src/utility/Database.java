package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Database {

	public static Connection getConnection() {
		Connection conn = null;

		try {
			String url = "jdbc:mysql://127.0.0.1:8889/StudentManagement";
			Class.forName("com.mysql.jdbc.Driver");

			try {

				conn = DriverManager.getConnection(url, "root", "root");

			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return conn;
	}

	public static List<Student> getStudents() {

		List<Student> student = new ArrayList<>();

		String Query = "Select * from student";
		Statement st;
		try {

			st = Database.getConnection().createStatement();
			ResultSet rs = st.executeQuery(Query);

			while (rs.next()) {
				Student s = new Student();
				s.setId(rs.getInt(1));
				s.setFirstName(rs.getString(2));
				s.setSecondName(rs.getString(3));
				s.setLastName(rs.getString(4));
				s.setEmail(rs.getString(5));
				s.setContact(rs.getString(6));
				s.setClassNo(rs.getInt(7));

				student.add(s);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return student;
	}

	public static void addStudent(Student s) {
		String Query = "INSERT INTO `student`(`firstname`, `secondname`, `lastname`, `email`, `contact`, `class`) "
				+ "VALUES (?,?,?,?,?,? )";
		PreparedStatement ps;
		try {

			ps = Database.getConnection().prepareStatement(Query);

			ps.setString(1, s.getFirstName());
			ps.setString(2, s.getSecondName());
			ps.setString(3, s.getLastName());
			ps.setString(4, s.getEmail());
			ps.setString(5, s.getContact());
			ps.setInt(6, s.getClassNo());

			ps.execute();

		} catch (

		SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void updateStudent(Student s) {
		String Query = "UPDATE `student` SET `firstname`=?,`secondname`=?,`lastname`=?,`email`=?,`contact`=?,`class`=? WHERE id = ?";
		PreparedStatement ps;
		try {

			ps = Database.getConnection().prepareStatement(Query);

			ps.setString(1, s.getFirstName());
			ps.setString(2, s.getSecondName());
			ps.setString(3, s.getLastName());
			ps.setString(4, s.getEmail());
			ps.setString(5, s.getContact());
			ps.setInt(6, s.getClassNo());
			ps.setInt(7, s.getId());
			ps.execute();

		} catch (

		SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void removeStudent(int id) {
		String Query = "Delete from student where id='" + id + "' ";
		try {

			PreparedStatement ps = Database.getConnection().prepareStatement(Query);
			ps.executeUpdate();

		} catch (

		SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
