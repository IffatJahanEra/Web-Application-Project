package utility;

public class Student {
	private int id;
	private String firstName;
	private String lastName;
	private String secondName;
	private String email;
	private String contact;
	private int classNo;

	public Student() {

	}

	public Student(int id, String firstName, String lastName, String secondName, String email, String contact,
			int classNo) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.secondName = secondName;
		this.email = email;
		this.contact = contact;
		this.classNo = classNo;
	}

	public int getClassNo() {
		return classNo;
	}

	public void setClassNo(int classNo) {
		this.classNo = classNo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSecondName() {
		return secondName;
	}

	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

}
