package Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utility.Database;
import utility.Student;

@WebServlet(name = "AddStudent", urlPatterns = { "/AddStudent" })
public class AddStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String firstName = request.getParameter("first");
		String secondName = request.getParameter("second");
		String lastName = request.getParameter("last");
		String email = request.getParameter("email");
		String contact = request.getParameter("contact");
		int classNo = Integer.valueOf(request.getParameter("classNo"));

		Student s = new Student(0, firstName, lastName, secondName, email, contact, classNo);
		Database.addStudent(s);

		response.sendRedirect("adminHome.jsp");
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
