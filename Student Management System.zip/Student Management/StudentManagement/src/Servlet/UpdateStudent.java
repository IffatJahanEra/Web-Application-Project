package Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utility.Database;
import utility.Student;

@WebServlet(name = "UpdateStudent", urlPatterns = { "/UpdateStudent" })
public class UpdateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String firstName = request.getParameter("first");
		String secondName = request.getParameter("second");
		String lastName = request.getParameter("last");
		String email = request.getParameter("email");
		String contact = request.getParameter("contact");
		int classNo = Integer.valueOf(request.getParameter("classNo"));
		int id = Integer.valueOf(request.getParameter("id"));

		Student s = new Student(id, firstName, lastName, secondName, email, contact, classNo);
		Database.updateStudent(s);

		response.sendRedirect("updateStudent.jsp");
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
